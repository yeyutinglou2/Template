KXC000001.log.clickSkip = function () {
    kitex.addDclog({
        _ac_type: 5,
        category: 'click_skip',
        current_time: (KXC000001.vpaid.currentTime / 1000).toFixed(2),
        vtime: (KXC000001.vpaid.duration / 1000).toFixed(2),
        skip_show_time: (KXC000001.vpaid.skipShowTime / 1000).toFixed(2),
    }, kitex.data.ads[0].vid)
}
KXC000001.log.reward = function (currentTime, duration) {
    kitex.addDclog({
        _ac_type: 5,
        category: 'reward',
        current_time: (currentTime / 1000).toFixed(2),
        vtime: (duration / 1000).toFixed(2),
        set_close_time: KXC000001.vpaid.isCutOff,
    }, kitex.data.ads[0].vid)
}
KXC000001.log.charged = function (currentTime, duration) {
    kitex.addDclog({
        _ac_type: 5,
        category: 'finish',
        current_time: (currentTime / 1000).toFixed(2),
        vtime: (duration / 1000).toFixed(2),
        set_close_time: KXC000001.vpaid.isCutOff,
    }, kitex.data.ads[0].vid)
}