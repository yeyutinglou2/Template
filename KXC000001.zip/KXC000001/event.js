KXC000001.event.makeNode = function (params) {
    if (params.type === "SkipView") {
        var control = new kitex.SkipViewControl(params);
        KXC000001.skipViewControls.push(control);
        if (params.tid == 'KXC000008') {
            KXC000001.event.skipControlEvent(control); 
            let time = Math.floor(KXC000001.vpaid.currentTime / 1000);
            control.updateTime(time);
        }
    } else if (params.type === "TextTimer") {
        var control = new kitex.TextTimerControl(params);
        KXC000001.textTimerControls.push(control);
    } else if (params.type === "Vpaid") {
        KXC000001.event.vpaidInit(params);
    }
}
KXC000001.event.vpaidReadyToPlay = function (vpaid, params) {
    let bidResponse = kitex.data;
    let end_time = bidResponse.slot_ad_setting.rv_setting.end_time;
    KXC000001.vpaid.duration = params.totalTime;
    KXC000001.event.updateDuration();
    KXC000001.vpaid.rewardTime = KXC000001.event.getRewardTimeMS();
    KXC000001.vpaid.chargeTime = KXC000001.event.getChargeTimeMS();
    let reward_seconds = KXC000001.event.getRewardTimeMS();
    KXC000001.setting.reward_seconds = Math.floor(reward_seconds / 1000);
    KXC000001.vpaid.rewardTimeRemaining = Math.floor(reward_seconds / 1000);
    vpaid.muted(KXC000001.setting.if_mute);
    vpaid.play();
    KXC000001.vpaid.id = params.nodeId;
    let skipControls = KXC000001.skipViewControls.filter(function (item) {
        return item.bindId === params.nodeId;
    });
    skipControls.forEach(element => {
        KXC000001.event.skipControlEvent(element);
    });
    KXC000001.vpaid.textTimerControl = KXC000001.textTimerControls.find(function (item) {
        return item.bindId === params.nodeId;
    });
    if (KXC000001.vpaid.textTimerControl) {
        KXC000001.vpaid.textTimerControl.setTime(reward_seconds / 1000);
    }
}
KXC000001.event.skipControlEvent = function(control) {
    if (control == undefined) return;
    let totalTime = KXC000001.vpaid.duration;
    let skipTimes = KXC000001.event.getSkipTimeMS();
    KXC000001.vpaid.skipShowTime = skipTimes;
    control.setTime(Math.floor(totalTime / 1000), Math.floor((totalTime - skipTimes) / 1000));
}
KXC000001.event.vpaidUpdateTime = function (nodeId, currentTime) {
    if (KXC000001.vpaid.duration == 0) {
        return;
    }
    KXC000001.vpaid.currentTime = currentTime;
    let time = Math.floor(currentTime / 1000);

    if (KXC000001.vpaid.rewardTimeRemaining > 0) {
        KXC000001.vpaid.rewardTimeRemaining = KXC000001.setting.reward_seconds - time;
    }
    let skipControls = KXC000001.skipViewControls.filter(function (item) {
        return item.bindId === nodeId;
    });
    skipControls.forEach(element => {
        element.updateTime(time);
    });
    let textTimerControl = KXC000001.vpaid.textTimerControl;
    if (textTimerControl) {
        textTimerControl.updateTime(time);   
    }
    let duration = KXC000001.vpaid.duration;
    let rewardTime = KXC000001.vpaid.rewardTime - currentTime;
    if (rewardTime <= 0 && KXC000001.vpaid.isRwearded != true) {
        KXC000001.vpaid.isRwearded = true;
        KXC000001.log.reward(currentTime, duration);
        kitex.ad.reward({});
    }
    if (currentTime >= KXC000001.vpaid.chargeTime && KXC000001.vpaid.isCharged != true) {
        KXC000001.vpaid.isCharged = true;
        KXC000001.log.reward(currentTime, duration);
    }
}
KXC000001.event.vpaidControl = function (state) {
    var control = KXC000001.vpaids.filter(function (item) {
        return item.bindId === KXC000001.vpaid.id;
    })
    if (!control || control.length === 0) {
        return;
    }
    var v = control[0];
    if (state === 'play') {
        v.play();
    } else if (state === 'pause') {
        v.pause();
    } else if (state === 'stop') {
        v.stop();
    }
}

KXC000001.event.updateDuration = function () {
    let duration = KXC000001.vpaid.duration;
    if (KXC000001.setting.isCutOff) {
        return duration;
    }
    let end_time = kitex.data.slot_ad_setting.rv_setting.end_time || 0;
    let canCutOff = end_time > 0 && end_time * 1000 < duration;
    KXC000001.setting.isCutOff = canCutOff
    if (canCutOff) {
        KXC000001.vpaid.duration = end_time * 1000;
        return KXC000001.vpaid.duration
    }
    return duration;
}
KXC000001.event.getSettingTimeMS = function (seconds, percent) {
    let duration = KXC000001.vpaid.duration;
    if (!duration) {
        return 0
    }
    if (seconds >= 0) {
        return Math.min(seconds * 1000, duration);
    }
    if (percent != undefined) {
        percent = Math.min(percent, 100);
        return duration * (percent / 100.0);
    }
    return duration;
}
KXC000001.event.getSkipTimeMS = function () {
    let bidResponse = kitex.data;
    let skip_seconds = bidResponse.slot_ad_setting.rv_setting.skip_seconds;
    let skip_percent = bidResponse.slot_ad_setting.rv_setting.skip_percent;
    return KXC000001.event.getSettingTimeMS(skip_seconds, skip_percent);
}
KXC000001.event.getChargeTimeMS = function () {
    let bidResponse = kitex.data;
    let charge_seconds = bidResponse.slot_ad_setting.rv_setting.charge_seconds;
    let charge_percent = bidResponse.slot_ad_setting.rv_setting.charge_percent;
    return KXC000001.event.getSettingTimeMS(charge_seconds, charge_percent);
}
KXC000001.event.getRewardTimeMS = function () {
    let bidResponse = kitex.data;
    let reward_seconds = bidResponse.slot_ad_setting.rv_setting.reward_seconds;
    let reward_percent = bidResponse.slot_ad_setting.rv_setting.reward_percent;
    return KXC000001.event.getSettingTimeMS(reward_seconds, reward_percent);
}
