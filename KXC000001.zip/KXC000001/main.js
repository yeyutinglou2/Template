required('KXC000001/log.js');
required('KXC000001/event.js');
// vapid组件
var KXC000001 = {
    tid: 'KXC000001',
    event: {},
    log: {},
    vpaid: {
        id: undefined,
        isRwearded: false,
        isCharged: false,
        rewardTimeRemaining: 0,
        duration: 0,
        currentTime: 0,
        rewardTime: undefined,
        skipControl: undefined,
        textTimerControl: undefined,
        skipShowTime: undefined,
    },
    setting: {
        dialogId: 'KXC000002',
        feedBackId: 'KXC000005',
        countDownState: 0,
        reward_seconds: 10,
        reward_style: kitex.data.slot_ad_setting.rv_setting.reward_style || 0,
    },
    skipViewControls: [],
    textTimerControls: [],
    vpaids: [],
    curVpaidId: undefined,
    dialog: undefined,
};
(function () {
    // 监听事件 模版环境初始化完成
    kitex.addEventListener(KXC000001.tid, 'ready', function () {
        console.log('---------- KXC000001.ready ----------');
    })
    // 监听事件 处理自定义组件的创建
    kitex.addEventListener(KXC000001.tid, 'makeNode', function (params) {
        KXC000001.event.makeNode(params);
    })
    KXC000001.event.vpaidInit = function (params) {
        var if_mute = kitex.data.slot_ad_setting.rv_setting.if_mute || 0;
        var control = new kitex.Vpaid(params);
        KXC000001.setting.if_mute = if_mute === 1;
        KXC000001.vpaids.push(control);
        KXC000001.event.addVpaidEvent(control);
        var video_url = kitex.data.ads[0].materials[0].video_url
        control.assetURL(video_url);
    }
    KXC000001.event.addVpaidEvent = function (vpaid) {
        vpaid.addEventListener('ready', function (params) {
            console.log('prepareToPlay:' + JSON.stringify(params));
            KXC000001.event.vpaidReadyToPlay(vpaid, params);

        });
        vpaid.addEventListener('playStateChanged', function (params) {
            console.log('playStateChanged:' + JSON.stringify(params));
        });
        vpaid.addEventListener('loadStateChanged', function (params) {
            console.log('loadStateChanged:' + JSON.stringify(params));
        });
        vpaid.addEventListener('currentTime', function (params) {
            KXC000001.event.vpaidUpdateTime(params.nodeId, params.currentTime);
            if (typeof (KXC000001.vpaid.updateTime) == 'function') {
                KXC000001.vpaid.updateTime(params);
            }
        });
        vpaid.addEventListener('playEnd', function (params) {
            console.log('playEnd:' + JSON.stringify(params));
            if (typeof (KXC000001.vpaid.playEnd) == 'function') {
                KXC000001.vpaid.playEnd(params);
            }
            kitex.postMessage({ tid: KXC000001.tid, type: "vapid", value: 'playEnd', paramss:params });
        });
        vpaid.addEventListener('error', function (params) {
            console.log('error:' + JSON.stringify(params));
        });
    }
})();