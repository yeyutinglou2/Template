var KXC100001 = {
    tid: 'KXC100001',
    event: {},
    widget: undefined,
}
// 监听事件 模版环境初始化完成
kitex.addEventListener(KXC100001.tid, 'ready', function () {
    KXC100001.event.lottieWidgetEvent(KXC100001.widget);
})
// 监听事件 处理自定义组件的创建
kitex.addEventListener(KXC100001.tid, 'makeNode', function (params) {
    KXC100001.event.makeNode(params);
})
kitex.addEventListener(KXC100001.tid, 'viewableChange', function (viewable) {
    console.log('[main].viewableChange: ' + JSON.stringify(viewable));
})

KXC100001.event.makeNode = function (params) {
    if (params.type == 'LottieView') {
        KXC100001.widget = new kitex.Lottie(params);
        return;
    }
}

KXC100001.event.lottieWidgetEvent = function (lottie) {
    lottie.addEventListener("animationLoaded", function (event) {
        lottie.play(0, 1, 0);
    });
    lottie.addEventListener("completed", function (event) {
        console.log("lottie.animation.completed");
    });
    let imageProviderPath = kitex.path + "/KXR100001/images/";
    let filepath = kitex.path + "/KXR100001/data.json";
    lottie.imageProvider(imageProviderPath);
    lottie.filepath(filepath);
}