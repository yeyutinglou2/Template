// 反馈弹窗组件
var KXC11501 = {
    tid: 'KXC11501',
    lottie: undefined,
    event: {},
    setting: {
        feedBackId: 'KXC000005',
    },
};
// 监听事件 模版环境初始化完成
kitex.addEventListener(KXC11501.tid, 'ready', function () {
    console.log('---------- KXC11501.kitex.ready ----------');
})
// 监听事件 处理自定义组件的创建
kitex.addEventListener(KXC11501.tid, 'makeNode', function (params) {
    console.log('---------- KXC11501.kitex.makeNode ----------' + JSON.stringify(params));
    if (params.type == 'LottieView') {
        KXC11501.lottie = new kitex.Lottie(params);
        KXC11501.event.lottie();
    }
})
kitex.animation.addEventListener(KXC11501.tid, 'mask_container', function () {
    console.log('animation.mask_container onFinish');
});
KXC11501.event.lottie = function () {
    let lottie = KXC11501.lottie;
    if (lottie == undefined) {
        return;
    }
}
KXC11501.event.showEndcard = function () {
    KXC900001.event.show();
    kitex.animation.trigger(KXC11501.tid, 'mask_container');
    let lottie = KXC11501.lottie;
    if (lottie != undefined) {
        lottie.play(0, 1, 1);
    }

}
KXC11501.event.maskClick = function (event) {
    kitex.postMessage({
        tid: KXC11501.tid,
        value: 'deleteNode',
        params: {
            ids: ['lottie_container'],
        }
    });
    event.params = {};
    event.dcParams = {};
    kitex.ad.openByVid(event);
}
KXC11501.event.closeAd = function (event) {
    kitex.ad.closed(event);
}
KXC11501.event.feedbackClick = function () {
    KXC11501.event.dialogShowCustom(KXC11501.setting.feedBackId, {
        vid: kitex.data.ads[0].vid
    });
}
KXC11501.event.dialogShowCustom = function(componentId, params) {
    var params = {
        type: 'custom',
        componentId: componentId,
        params: params
    };
    var dialog = new kitex.Dialog(params);
    KXC11501.dialog = dialog;
    dialog.show();
}

KXC11501.event.dismissDialog = function () {
    if (!KXC11501.dialog) {
        return;
    }
    KXC11501.dialog.dismiss();
    KXC11501.dialog = undefined;
}
KXC11501.event.onClick = function (event) {
    kitex.ad.openByVid(event);
}

