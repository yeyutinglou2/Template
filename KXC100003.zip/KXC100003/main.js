var KXC100003 = {
    tid: 'KXC100003',
    event: {},
    widget: undefined,
}
// 监听事件 模版环境初始化完成
kitex.addEventListener(KXC100003.tid, 'ready', function () {
    KXC100003.event.lottieWidgetEvent(KXC100003.widget);
})
// 监听事件 处理自定义组件的创建
kitex.addEventListener(KXC100003.tid, 'makeNode', function (params) {
    KXC100003.event.makeNode(params);
})
kitex.addEventListener(KXC100003.tid, 'viewableChange', function (viewable) {
    console.log('[main].viewableChange: ' + JSON.stringify(viewable));
})
KXC100003.event.makeNode = function (params) {
    if (params.type == 'LottieView') {
        KXC100003.widget = new kitex.Lottie(params);
        return;
    }
}

KXC100003.event.lottieWidgetEvent = function (lottie) {
    lottie.addEventListener("animationLoaded", function (event) {
        lottie.play(0, 1, 0);
    });
    lottie.addEventListener("completed", function (event) {
        console.log("lottie.animation.completed");
    });
    let imageProviderPath = kitex.path + "/KXR100003/images/";
    let filepath = kitex.path + "/KXR100003/data.json";
    lottie.imageProvider(imageProviderPath);
    lottie.filepath(filepath);
}