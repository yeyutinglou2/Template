var KXC000008 = {
    tid: 'KXC000008',
    lottie: undefined,
    makeNodes: [],
    setting: {
        reward_state: 1,
        retry_state: 1,
        closed_state: 1,
    }
};
kitex.addEventListener(KXC000008.tid, 'makeNode', function (params) {
    if (params.type === 'LottieView') {
        KXC000008.lottie = new kitex.Lottie(params);
        KXC000008.lottieEvent(KXC000008.lottie);
    }
    KXC000001.event.makeNode(params);
})
kitex.addEventListener(KXC000008.tid, 'ready', function () {
    let params = KXC000008.params;
    if (!params) return;
    if (params.reward_state != undefined) {
        KXC000008.setting.reward_state = params.reward_state || 0;
        KXC000008.setting.retry_state = params.retry_state || 0;
        KXC000008.refresh(['left_reward_id', 'right_reward_id']);
    }
    KXC000008.setting.closed_state = 0;
    KXC000008.refresh(['closed_id']);
})
KXC000008.refresh = function (ids) {
    kitex.postMessage({
        tid: KXC000008.tid,
        value: 'refresh',
        params: {
            ids: ids,
        }
    })
}
KXC000008.lottieEvent = function (lottie) {
    let params = KXC000008.params;
    lottie.textProvider({
        _AD_TITLE_01_: params._AD_TITLE_01_,
        _AD_TITLE_02_: params._AD_TITLE_02_,
        _TEXTSWING_: params._TEXTSWING_,
        _CTA_TEXT_: params._CTA_TEXT_,
        _TIME_SECOND_: params._TIME_SECOND_,
        _APP_NAME_: params._APP_NAME_,
        _AD_DESC_: params._AD_DESC_,
    });
    lottie.imageProvider(params.imageProviderPath);
    lottie.filepath(params.filepath);
    lottie.addResources([
        {
            name: "img_2.png",
            content: params.icon_url
        }
    ]);
}
KXC000008.rewardTxt = function (state) {
    let params = KXC000008.params;
    if (!params) return undefined;
    if (state == 0) {
        return params.reward_txt;
    }
    return params.retry_txt;
}
KXC000008.feedbackClick = function (event) {
    main.event.feedbackClick(event, true);
}