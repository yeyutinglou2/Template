// 伴随条组件（标题+评分）
var KXC000004 = {
    tid: 'KXC000004',
    event: {},
}
// 监听事件 模版环境初始化完成
kitex.addEventListener(KXC000004.tid, 'ready', function () {
    console.log('---------- KXC000004.kitex.ready ----------');
})
KXC000004.color = {
    barColor: function() {
        console.log('---------- KXC000004.barColor ----------');
        return '#ffffff';
    },
    buttonColor: function() {
        console.log('---------- KXC000004.buttonColor ----------');
        return 'red';
    },
    buttonTextColor: function() {
        console.log('---------- KXC000004.buttonTextColor ----------');
        return 'white';
    }
}

KXC000004.event.ctaClick = function(event) {
    console.log('[KXC000004].ctaClick');
    kitex.ad.openByVid(event);
}

KXC000004.event.onClick = function(event) {
    console.log('[KXC000004].onClick');
    kitex.ad.openByVid(event);
}

