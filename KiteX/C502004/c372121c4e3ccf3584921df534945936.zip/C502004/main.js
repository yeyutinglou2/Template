required("C502004/event.js");

var C502004 = {
    tid: "C502004",
    event: {},
    track: {},
    utils: {},
    lottie_bg: undefined,
    lottie_card: undefined,
    lottie_widget: undefined,
    motion: undefined,
    vpaid: undefined,
    setting: {
        creative_type: 0,
        /* 0：竖版资源，1：横版资源 */
        resourceDirection: 0,
        /* 倒计时时长 */
        totolTime: 5,
    },
    state: {},
    frameId: "502004",
};

/* 监听事件，模版环境初始化完成 */
kitex.addEventListener(C502004.tid, "ready", function () {
    C502004.event.ready();
});

/* 监听事件，处理自定义组件的创建 */
kitex.addEventListener(C502004.tid, "makeNode", function (params) {
    C502004.event.makeNode(params);
});

kitex.addEventListener(C502004.tid, "enterBackground", function () {});

kitex.addEventListener(C502004.tid, "enterForeground", function () {});

kitex.addEventListener(C502004.tid, "viewableChange", function (viewable) {
    console.log("[C502004].viewableChange: " + JSON.stringify(viewable));
    C502004.event.viewableChange(viewable);
});