var KXC100002 = {
    tid: 'KXC100002',
    event: {},
    setting: {
        positionId: '_BG_POSITION_'
    },
    widget: undefined,
}
// 监听事件 模版环境初始化完成
kitex.addEventListener(KXC100002.tid, 'ready', function () {
    KXC100002.event.lottieWidgetEvent(KXC100002.widget);
})
// 监听事件 处理自定义组件的创建
kitex.addEventListener(KXC100002.tid, 'makeNode', function (params) {
    KXC100002.event.makeNode(params);
})
kitex.addEventListener(KXC100002.tid, 'viewableChange', function (viewable) {
    console.log('[main].viewableChange: ' + JSON.stringify(viewable));
})
kitex.animation.addEventListener("image_id", function (event) {
    console.log("[main].animation.finish.image_id");
    // kitex.postMessage({
    //     tid: KXC100002.tid,
    //     value: 'deleteNode',
    //     params: {
    //         ids: ['image_id'],
    //     }
    // })
    KXC100002.widget.remove(KXC100002.setting.positionId);

});
KXC100002.event.makeNode = function (params) {
    if (params.type == 'LottieView') {
        KXC100002.widget = new kitex.Lottie(params);
        return;
    }
}

KXC100002.event.lottieWidgetEvent = function (lottie) {
    lottie.addEventListener("animationLoaded", function (event) {
        lottie.play(0, 1, 0);
        lottie.addNode(KXC100002.setting.positionId, "image_id");
    });
    lottie.addEventListener("completed", function (event) {
        console.log("lottie.animation.completed");
    });
    let imageProviderPath = kitex.path + "/KXR100002/images/";
    let filepath = kitex.path + "/KXR100002/data.json";
    lottie.imageProvider(imageProviderPath);
    lottie.filepath(filepath);
}