required('KXT01010115/event.js')
required('KXT01010115/log.js')

var main = {
    tid: 'KXT01010115',
    vpaid_tid: 'KXC000001',
    event: {},
    log: {},
    makeNodes: [],
    setting: {
        dialogId: 'KXC000002',
        feedBackId: 'KXC000005',
        countDownState: 0,
        reward_seconds: 10,
        reward_style:  1,
    },
}
// 监听事件 模版环境初始化完成
kitex.addEventListener(main.tid, 'ready', function () {
    console.log('[main].ready');
    kitex.countDown.addEventListener(main.tid, 'text_timer_id', main.event.countDownListener);
})
kitex.addEventListener(main.vpaid_tid, 'ready', function () {
    console.log('[vpaid].ready'); 
    KXC000001.vpaid.playEnd = main.event.playEnd;
    KXC000001.event.dialogCloseAdCallback = main.event.dialogCloseAd;
    main.makeNodes.forEach(params => {
        KXC000001.event.makeNode(params);
    })
})
kitex.addEventListener(main.tid, 'enterBackground', function () {
    console.log('[main].enterBackground');
})
kitex.addEventListener(main.tid, 'enterForeground', function () {
    console.log('[main].enterForeground');
})
kitex.addEventListener(main.tid, 'viewableChange', function (viewable) {
    console.log('[main].viewableChange: ' + JSON.stringify(viewable));
})
// 监听事件 处理自定义组件的创建
kitex.addEventListener(main.tid, 'makeNode', function (params) {
    console.log('[main].makeNode: ' + JSON.stringify(params)); 
    main.makeNodes.push(params);
})
