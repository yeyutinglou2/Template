main.event.playEnd = function () {
    kitex.postMessage({ tid: main.vpaid_tid, type: "vapid", value: 'playEnd', paramss:{}});
    main.event.removeVapid();
    KXC11501.event.showEndcard();
    kitex.postMessage({
        tid: main.tid,
        value: 'deleteNode',
        params: {
            ids: ['vpaid_control_root_id']
        }
    })
}

main.event.dialogCloseAd = function (event) {
    let bidResponse = kitex.data;
    let enable_exit_on_video_close = bidResponse.slot_ad_setting.rv_setting.enable_exit_on_video_close || false;
    if (enable_exit_on_video_close) {
        kitex.ad.closed(event);
    }else {
        main.event.removeVapid();
        KXC11501.event.showEndcard();
    }
}

main.event.removeVapid = function () {
    kitex.postMessage({
        tid: main.tid,
        value: 'deleteNode',
        params: {
            ids: ['vpaid_id', 'logo_container'],
        }
    })
}

main.event.soundClick = function (event) {
    var vpaid = KXC000001.vpaids[0];
    if (!vpaid) {
        return;
    }
    main.setting.if_mute = !main.setting.if_mute;
    vpaid.muted(main.setting.if_mute);
    kitex.postMessage({
        tid: main.tid,
        value: 'refresh',
        params: {
            ids: [event.nodeId],
        }
    })
}
main.event.skipClick = function (event) {
    main.log.clickSkip();
    kitex.ad.skip(event);
    let confirm_dialog = kitex.data.slot_ad_setting.rv_setting.confirm_dialog;
    if (KXC000001.vpaid.rewardTimeRemaining <= 0 || confirm_dialog == 2) {
        KXC000001.event.vpaidControl('pause');
        main.event.dialogCloseAd();
        return;
    }
    main.event.showSkipDialog();
}
main.event.showSkipDialog = function () {
    var params = {
        title: '要放弃领取奖励吗？',
        message: '仅需再浏览' + KXC000001.vpaid.rewardTimeRemaining + '秒广告，即可领取奖励',
        cancel: '继续观看',
        confirm: '关闭广告',
        cancelEvent: 'main.event.dismissDialog',
        confirmEvent: 'main.event.dialogCloseAd',
    }
    main.event.dialogShowCustom(main.setting.dialogId, params);
}
main.event.feedbackClick = function (event) {
    main.event.dialogShowCustom(main.setting.feedBackId, {
        vid: kitex.data.ads[0].vid
    });
}
main.event.countDownListener = function () {
    main.setting.countDownState = 1;
    kitex.postMessage({
        tid: main.tid,
        value: 'deleteNode',
        params: {
            ids: ['text_timer_id'],
        }
    })
    kitex.postMessage({
        tid: main.tid,
        value: 'refresh',
        params: {
            ids: ['text_timer_text_id'],
        }
    })
}
main.event.dismissDialog = function () {
    if (!main.dialog) {
        return;
    }
    main.dialog.dismiss();
    main.dialog = undefined;
}
main.event.dialogCloseAd = function (event) {
    main.event.dismissDialog();
    main.event.playEnd();
}

main.event.dialogShowCustom = function (componentId, params) {
    var options = {
        type: 'custom',
        componentId: componentId,
        params: params
    };
    var dialog = new kitex.Dialog(options);
    main.dialog = dialog;
    dialog.onAppear(function () {
        KXC000001.event.vpaidControl('pause');
    });
    dialog.onDisappear(function () {
        KXC000001.event.vpaidControl('play');
    });
    dialog.show();
}