// 推荐子广告
var KXC900001 = {
    tid: 'KXC900001',
    event: {},
};
// 监听事件 模版环境初始化完成
kitex.addEventListener(KXC900001.tid, 'ready', function (params) {
    console.log('---------- KXC900001.kitex.ready ----------');
})
kitex.addEventListener(KXC900001.tid, 'makeNode', function (params) {
    console.log('---------- KXC900001.kitex.makeNode ----------' + JSON.stringify(params));
    if (params.type == 'Grid') {
        KXC900001.grid = new kitex.Grid(params);
        KXC900001.event.gridEvent();
    }
})
KXC900001.event.show = function () {
    KXC900001.event.datas = [
        {uid: 'x-1', src: 'https://is1-ssl.mzstatic.com/image/thumb/Purple116/v4/4f/94/60/4f9460c5-8902-0217-5b16-d0cb38bb6f7d/source/100x100bb.jpg', title: '测试标题1'},
        {uid: 'x-2', src: 'https://testn.sigmob.cn/rv/3/5ed3d480/b04dbfb6d4c5c987d2c172cf2c22ebae.png', title: '测试标题2'},
        {uid: 'x-3', src: 'https://testn.sigmob.cn/rv/3/5ed3d480/81127d229f743649785f67344f8321b5.jpeg', title: '测试标题3'},
        {uid: 'x-4', src: 'https://is1-ssl.mzstatic.com/image/thumb/Purple116/v4/4f/94/60/4f9460c5-8902-0217-5b16-d0cb38bb6f7d/source/100x100bb.jpg', title: '测试标题4'},
        {uid: 'x-5', src: 'https://testn.sigmob.cn/rv/3/5ed3d480/b04dbfb6d4c5c987d2c172cf2c22ebae.png', title: '测试标题5'},
        {uid: 'x-6', src: 'https://testn.sigmob.cn/rv/3/5ed3d480/81127d229f743649785f67344f8321b5.jpeg', title: '测试标题6'},
        {uid: 'x-7', src: 'https://testn.sigmob.cn/rv/3/5ed3d480/b04dbfb6d4c5c987d2c172cf2c22ebae.png', title: '测试标题7'},
    ]
    KXC900001.grid.dataSource(KXC900001.event.datas);
    KXC900001.grid.reloadData();
    KXC900001.grid.autoScroll();
}
KXC900001.event.gridEvent = function () {
    KXC900001.grid.addEventListener('willDisplay', function (params) {
        console.log('---------- KXC900001.grid.willDisplay ----------' + JSON.stringify(params));
    })
    KXC900001.grid.addEventListener('didSelectItem', function (params) {
        console.log('---------- KXC900001.grid.didSelectItem ----------' + JSON.stringify(params));
    })
}
