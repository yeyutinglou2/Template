main.event.ready = function () {
    console.log('[main].ready');
    main.event.lottieEndcardEvent(main.lottie_card);
    let material = kitex.data.ads[0].materials[0];
    main.setting.creative_type = material.creative_type;
    if (main.setting.creative_type == 3) {
        main.setting.positionId = 'image_id'
    }else if (main.setting.creative_type == 8) {
        main.setting.positionId = 'video_id'
    }
}
main.event.makeNode = function (params) {
    if (params.type == 'LottieView' && params.nodeId == "lottie_card_id") {
        main.lottie_card = new kitex.Lottie(params);
        return;
    }
    if (params.type == 'Vpaid') {
        main.event.vpaidInit(params);
        return;
    }
}
main.event.widgetId = function() {
    return 'KXC100002'
}
main.event.bgWidgetId = function() {
    return 'KXR900003'
}
main.event.bgImagePath = function() {
    let bgWidgetId = main.event.bgWidgetId();
    let imageProviderPath = kitex.path + "/" + bgWidgetId + "/images/img_3.jpg";
    return imageProviderPath;
}
main.event.lottieEndcardEvent = function (lottie) {
    lottie.addEventListener("animationLoaded", function (event) {
        lottie.play(0, 1, 0);
        if (main.setting.positionId) {
            lottie.addNode("_BG_POSITION_", main.setting.positionId);
        }
    });
    lottie.addEventListener("completed", function (event) {
        console.log("lottie.animation.completed");
    });
    let bgWidgetId = main.event.bgWidgetId();
    let imageProviderPath = kitex.path + "/" + bgWidgetId + "/images/";
    let filepath = kitex.path + "/" + bgWidgetId + "/data.json";

    lottie.imageProvider(imageProviderPath);
    lottie.filepath(filepath);
}
main.event.vpaidInit = function (params) {
    let vpaid = new kitex.Vpaid(params);
    main.event.addVpaidEvent(vpaid);
    let video_url = kitex.data.ads[0].materials[0].video_url
    vpaid.assetURL(video_url);
    main.vpaid = vpaid;
}
main.event.vpaidReadyToPlay = function (vpaid) {
    vpaid.play();
}
main.event.vpaidPlayToEnd = function (vpaid) {

}
main.event.addVpaidEvent = function (vpaid) {
    vpaid.addEventListener('ready', function (params) {
        console.log('[main].prepareToPlay:' + JSON.stringify(params));
        main.event.vpaidReadyToPlay(vpaid);
    });
    vpaid.addEventListener('playStateChanged', function (params) {
        console.log('[main].playStateChanged:' + JSON.stringify(params));
    });
    vpaid.addEventListener('loadStateChanged', function (params) {
        console.log('[main].loadStateChanged:' + JSON.stringify(params));
    });
    vpaid.addEventListener('currentTime', function (params) {
        
    });
    vpaid.addEventListener('playEnd', function (params) {
        console.log('[main].playEnd:' + JSON.stringify(params));
        main.event.vpaidPlayToEnd(params);
    });
    vpaid.addEventListener('error', function (params) {
        console.log('[main].error:' + JSON.stringify(params));
    });
}

