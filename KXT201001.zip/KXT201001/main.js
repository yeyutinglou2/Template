required('KXT201001/event.js')

var main = {
    tid: 'KXT201001',
    event: {},
    lottie_card: undefined,
    lottie_widget: undefined,
    setting: {
        creative_type: 0
    },
    state: {
    }
}
// 监听事件 模版环境初始化完成
kitex.addEventListener(main.tid, 'ready', function () {
    main.event.ready();
})
// 监听事件 处理自定义组件的创建
kitex.addEventListener(main.tid, 'makeNode', function (params) {
    main.event.makeNode(params);
})
kitex.addEventListener(main.tid, 'enterBackground', function () {
    
})
kitex.addEventListener(main.tid, 'enterForeground', function () {

})
kitex.addEventListener(main.tid, 'viewableChange', function (viewable) {
    console.log('[main].viewableChange: ' + JSON.stringify(viewable));
})