

main.event.ready = function () {
    console.log('[main].ready');
    console.log('[main].ad: ' + JSON.stringify(kitex.data));
    let material = kitex.data.ads[0].materials[0];
    main.setting.creative_type = material.creative_type;
    if (main.setting.creative_type == 3) {
        main.setting.positionId = 'image_root_id'
        let imageSize = material.image_size;
        main.event.getResourceDirection(imageSize)
    }else if (main.setting.creative_type == 8) {
        main.setting.positionId = 'video_id'
        let videoSize = material.video_size;
        main.event.getResourceDirection(videoSize)
    }
    if (!main.event.isHiddenBg()) {
        main.event.lottieBgEvent(main.lottie_bg);
    }
    if (!main.event.isHiddenCard()) {
        main.event.lottieCardEvent(main.lottie_card);
    }
    main.event.lottieWidgetEvent(main.lottie_widget);
}
main.event.viewableChange = function(viewable) {
    if (main.motion != null) {
        if (viewable) {
            main.motion.start();
        } else {
            main.motion.stop();
        }
    }
}
main.event.makeNode = function (params) {
    if (params.type == 'LottieView') {
        if (params.nodeId == "lottie_bg_id") {
            main.lottie_bg = new kitex.Lottie(params);
        } else if (params.nodeId == "lottie_card_id") {
            main.lottie_card = new kitex.Lottie(params);
        } else if (params.nodeId ==  "widget_id")  {
            main.lottie_widget = new kitex.Lottie(params);
        }
        return;
    }
    if (params.type == 'Vpaid') {
        main.event.vpaidInit(params);
        return;
    }
    if (params.type == 'SkipView') {
        let ad = kitex.data.ads[0];
        let totalTime = ad.slot_ad_setting.splash_setting.show_duration;
        if (main.vpaid && main.vpaid.duration > 3) {
            totalTime = Math.min(main.vpaid.duration, totalTime);
        }
        totalTime = 10;
        let skipTime = totalTime;
        main.setting.totalTime = totalTime;
        if (params.nodeId == "time_id") {
            let control = new kitex.SkipViewControl(params);
            control.setTime(totalTime, 0);
        } else {
            let control = new kitex.SkipViewControl(params);
            control.setTime(totalTime, skipTime);
        }
        return;
    }
}
main.event.resourceSize = function(params) {
    console.log('[main].resourceSize:' + JSON.stringify(params));
    if (params.nodeId == "image_id") {
        // main.event.loadBg(params);
    }
}
main.event.getResourceDirection = function(params) {
    if (params.height < params.width) {
        main.setting.resourceDirection = 1;
    }
    // main.event.lottieBgEvent(main.lottie_bg);
}
main.event.widgetId = function() {
    return '205115';
}
main.event.bgWidgetId = function() {
    return '502002';
}
main.event.cardWidgetId = function() {
    return main.event.bgWidgetId();
}
main.event.isHiddenBg = function() {
    let bgWidgetId = main.event.bgWidgetId();
    if (bgWidgetId == BGName.noneFrmae) {
        return true;
    }
    return false;
}
main.event.isHiddenCard = function() {
    let cardWidgetId = main.event.cardWidgetId();
    if (cardWidgetId == BGName.paparFrame) {
        return false;
    }
    return true;
}
main.event.isHiddenGif = function() {
    let widgetId = main.event.widgetId();
    if (widgetId == WidgetName.redPacketsVoucher) {
        return false;
    }
    return true;
}
main.event.isWidgetHiddenIcon = function() {
    let widgetId = main.event.widgetId();
    if (widgetId == WidgetName.whileDiffusionCard) {
        return false;
    }
    return true;
}
main.event.isCardHiddenIcon = function() {
    let cardWidgetId = main.event.cardWidgetId();
    if (cardWidgetId == BGName.paparFrame) {
        return false;
    }
    return true;
}
main.event.bgImagePath = function() {
    let bgWidgetId = main.event.bgWidgetId();
    let imagePath = kitex.path + "/" + bgWidgetId + "/BG-V/images/_BG_.png";
    return imagePath;
}
main.event.lottieBgEvent = function (lottie) {
    let bgWidgetId = main.event.bgWidgetId();
//    let containerPath = "_BG_POSTION_" + bgWidgetId + "_";
    let containerPath = "_BG_POSITION_";
    lottie.addEventListener("animationLoaded", function (event) {
        lottie.play(0, 1, 0);
        if (main.setting.positionId) {
            lottie.addNode(containerPath, main.setting.positionId);
        }
        console.log("lottieBg.animation.completed");
    });
    lottie.addEventListener("completed", function (event) {
        console.log("lottieBg.animation.completed");
    });
    let resourceName = main.setting.resourceDirection == 0 ? "BG-V" : "BG-H";
    let imageProviderPath = kitex.path + "/" + bgWidgetId + "/" + resourceName + "/images/";
    let filepath = kitex.path + "/" + bgWidgetId + "/" + resourceName + "/"+ bgWidgetId + ".json";

    lottie.imageProvider(imageProviderPath);
    lottie.filepath(filepath);
    // 更改标题
    let ad = kitex.data.ads[0];
    let material = ad.materials[0];
    let frameTitle = material.frame_title;
    lottie.textProvider({
        "_FRAME_TITLE_":frameTitle
    });
}
main.event.lottieCardEvent = function (lottie) {
    let cardWidgetId = main.event.cardWidgetId();
//    let containerPath = "_BG_POSTION_" + cardWidgetId + "_";
    let containerPath = "_BG_POSITION_";
    lottie.addEventListener("animationLoaded", function (event) {
        lottie.play(0, 1, 0);
        if (main.setting.positionId) {
            lottie.addNode(containerPath, main.setting.positionId);
        }
        if (!main.event.isCardHiddenIcon()) {
            let containerPath = "_APP_ICON_";
            lottie.addNode(containerPath, "card_icon_id");
        }
        // 按钮点击
        let clickAreas = [
            "_CLICK_",
        ];
        clickAreas.forEach((val, index) => {
            lottie.addClick(val, function (params) {
                console.log('[main].widget.click: ' + JSON.stringify(params));
                kitex.ad.openByVid(params);
            });
        });
    });
    lottie.addEventListener("completed", function (event) {
        console.log("lottieCard.animation.completed");
    });
    let resourceName = main.setting.resourceDirection == 0 ? "News-V" : "News-H";
    let imageProviderPath = kitex.path + "/" + cardWidgetId + "/" + resourceName + "/images/";
    let filepath = kitex.path + "/" + cardWidgetId + "/" + resourceName + "/" + cardWidgetId + ".json";

    lottie.imageProvider(imageProviderPath);
    lottie.filepath(filepath);
    
    // 替换lottie文本
    let ad = kitex.data.ads[0];
    let material = ad.materials[0];
    let frameTitle = material.frame_title;
    let appName = material.app_name;
    let appDesc = material.app_desc;
    let buttonText = material.frame_button_text;
    if (!isValidString(frameTitle)) {
        frameTitle = "今日热门推荐";
    }
    lottie.textProvider({
        "_FRAME_TITLE_": frameTitle,
        "_APP_NAME_": appName,
        "_APP_DESC_": appDesc,
        "_FRAME_CTA_TEXT_": buttonText,
        "_DATE_": main.utils.currentDate()
    });
    let buttonColor = material.frame_button_color;
    lottie.colorProvider("_FRAME_CTA_BG_.矩形 1.填充 1.Color", buttonColor);
}
main.event.gifImagePath = function() {
    let widgetId = main.event.widgetId();
    let imagePath = kitex.path + "/" + widgetId + "/red_packet.gif";
    return imagePath;
}
main.event.lottieWidgetEvent = function (lottie) {
    let widgetId = main.event.widgetId();
    if (main.utils.bannerTimer(widgetId)) {
        let seconds = main.setting.totalTime;
        console.log(seconds);
        let token = kitex.setInterval(function() {
            seconds--;
            lottie.textProvider({"_TIME_":""});
            console.log('[main].TIME:' + seconds);
            if (seconds <= 1) {
                kitex.clearInterval(token);
            }
        }, 1000);
    }
    lottie.addEventListener("animationLoaded", function (event) {
        lottie.play(0, 1, 0);
        main.event.interactiveEvent(lottie);
        if (!main.event.isHiddenGif()) {
            let containerPath = "_HB_GIF_";
            lottie.addNode(containerPath, "gif_id");
        }
        if (!main.event.isWidgetHiddenIcon()) {
            let containerPath = "_APP_ICON_";
            lottie.addNode(containerPath, "widget_icon_id");
        }
        if (main.utils.bannerTimer(widgetId)) {
            let containerPath = "_BG_COUNTDOWN_";
            lottie.addNode(containerPath, "time_id");
        }
    });
    lottie.addEventListener("completed", function (event) {
        console.log("lottie.animation.completed");
    });
    let imageProviderPath = kitex.path + "/" + widgetId  + "/images/";
    let filepath = kitex.path +  "/" + widgetId + "/"+ widgetId + ".json";
    lottie.imageProvider(imageProviderPath);
    lottie.filepath(filepath);
    let ad = kitex.data.ads[0];
    let material = ad.materials[0];
    let title = material.title;
    let desc = material.desc;
    console.log('[main].title:' + title + "desc:" + desc);
    if (main.utils.isUseDefaultText(widgetId)) {
        if (!isValidString(title)) {
            title =  main.utils.getDefaultTitle(widgetId);
        }
        if (!isValidString(desc)) {
            desc =  main.utils.getDefaultDesc();
        }
    }
    console.log('[main].title:' + title + "desc:" + desc);
    let creativeTitle = material.creative_title;
    
    let creativeDesc = material.creative_desc;
    let buttonText = material.button_text;
    let tipLeft = material.tip_left;
    let tipRight = material.tip_right;
    if (main.utils.bannerTimer(widgetId)) {
        if (!isValidString(creativeTitle)) {
            creativeTitle = "限时获取 名额有限";
        }
        if (!isValidString(creativeDesc)) {
            creativeDesc = "超级福利火热领取中";
        }
        if (!isValidString(tipLeft)) {
            tipLeft = "恭喜获得奖励";
        }
        if (!isValidString(tipRight)) {
            tipRight = "后结束";
        }
    }
    lottie.textProvider({
        "_TEXT_ACT_01_": title,
        "_TEXT_ACT_02_": desc,
        "_TIP_TEXT_LEFT_": tipLeft,
        "_TIP_TEXT_RIGHT_": tipRight,
        "_AD_TITLE_": creativeTitle,
        "_AD_DESC_": creativeDesc,
        "_INT_TEXT_": title + desc,
        "_CTA_TEXT_":buttonText.length ? buttonText : "点击查看详情"
    });
    let buttonColor = material.button_color;
    lottie.colorProvider("_CTA_BG_.矩形 1.填充 1.Color", buttonColor);

}
/** 互动事件处理 */
main.event.interactiveEvent = function (lottie) {
    // 互动挂件
//    console.log('[main].ad: ' + JSON.stringify(kitex.data));
    let ad = kitex.data.ads[0];
    let material = ad.materials[0];
    let adSetting = ad.ad_setting;
    let widgetId = main.event.widgetId();
    let interactiveType = main.utils.getInteractiveType(widgetId);
    let sensitivity = adSetting.sensitivity;
    if (interactiveType ==  InteractiveType.motion || interactiveType == InteractiveType.slide) { // 陀螺仪和滑动
        let motionType = main.utils.getMotionType(widgetId);
        if (motionType != MotionType.unknown) {
            main.motion = new kitex.Motion(motionType);
            main.event.motionEvent(main.motion);
        }
        // 互动组件点击
        if (material.click_type == 1) {
            // 挂件点击
            let clickAreas = [
                "_CLICK_",
                "_CLICK_01_",
                "_CLICK_02_",
            ];
            clickAreas.forEach((val, index) => {
                lottie.addClick(val, function (params) {
                    console.log('[main].widget.click: ' + JSON.stringify(params));
                    kitex.ad.openByVid(params);
                });
            });
        }
        // if (interactiveType == InteractiveType.slide) {
        //     let distance = main.utils.getSlideDistance(sensitivity);
        //     lottie.addSlide("滑动手机至banner动效", distance, function (params) {
        //         console.log('[main].widget.slide: ' + JSON.stringify(params));
        //         kitex.ad.openByVid(params);
        //     });
        // }
    }

    
//    if (widgetId == WidgetName.snake) {
//
//    } else {
//        lottie.textProvider({"_WIDGET_TITLE_":title});
//        lottie.textProvider({"_WIDGET_DES_":desc});
//    }

    
}

function isValidString(val) {
    if (val == null || !(typeof val  === "string") || (typeof val === "string" && val.length == 0)) {
        return false
    }
    return true
}

main.event.motionEvent = function (motion) {
    motion.start();
    motion.addEventListener("start", function(params) {
        console.log('[main].motion.start: ' + JSON.stringify(params));
    });
    motion.addEventListener("end", function(params) {
        console.log('[main].motion.end: ' + JSON.stringify(params));
    });
    motion.addEventListener("progress", function(params) {
        console.log('[main].motion.progress: ' + JSON.stringify(params));
    });
}
main.event.vpaidInit = function (params) {
    let vpaid = new kitex.Vpaid(params);
    main.event.addVpaidEvent(vpaid);
    let video_url = kitex.data.ads[0].materials[0].video_url
    vpaid.assetURL(video_url);
    main.vpaid = vpaid;
}
main.event.vpaidReadyToPlay = function (vpaid) {
    vpaid.play();
}
main.event.vpaidPlayToEnd = function (vpaid) {
    kitex.postMessage({
        tid: vpaid.tid,
        type: vpaid.type,
        value: 'vpaidPlayToEnd',
        params: {
            nodeId: vpaid.nodeId
        }
    });
}
main.event.addVpaidEvent = function (vpaid) {
    vpaid.addEventListener('ready', function (params) {
        console.log('[main].prepareToPlay:' + JSON.stringify(params));
        main.event.vpaidReadyToPlay(vpaid);
        // main.event.loadBg(params);
    });
    vpaid.addEventListener('playStateChanged', function (params) {
        console.log('[main].playStateChanged:' + JSON.stringify(params));
    });
    vpaid.addEventListener('loadStateChanged', function (params) {
        console.log('[main].loadStateChanged:' + JSON.stringify(params));
    });
    vpaid.addEventListener('currentTime', function (params) {
        
    });
    vpaid.addEventListener('playEnd', function (params) {
        console.log('[main].playEnd:' + JSON.stringify(params));
        main.event.vpaidPlayToEnd(params);
    });
    vpaid.addEventListener('error', function (params) {
        console.log('[main].error:' + JSON.stringify(params));
    });
}
main.event.countDownListener = function() {
    main.track.countdownFinish();
    main.track.close();
    main.event.destory();
    kitex.postMessage({
        tid: main.tid,
        type: 'ad',
        value: 'countdownFinish',
    });
}

main.event.skipClick = function (event) {
    main.track.clickSkip();
    main.track.close();
    main.event.destory();
    kitex.ad.skip(event);
}

main.event.destory = function() {
//    if (main.event.isHiddenCard) {
//        main.lottie_bg.remove(["_BG_POSITION_"]);
//    } else {
//        main.lottie_card.remove(["_BG_POSITION_"]);
//    }
   
}


main.event.distance = function() {
//     console.log('[main].distance:' + JSON.stringify(kitex.data));
    let ad = kitex.data.ads[0];
    let adSetting = ad.ad_setting;
    let sensitivity = adSetting.sensitivity;
    let distance = main.utils.getSlideDistance(sensitivity);
    return distance;
}
main.event.click = function (params) {
    let widgetId = main.event.widgetId();
    if (main.utils.isSlide(widgetId)) {
        kitex.ad.openByVid(params);
    }
}

