

main.event.ready = function () {
    console.log('[main].ready');   
    let material = kitex.data.ads[0].materials[0];
    main.setting.creative_type = material.creative_type;
    if (main.setting.creative_type == 3) {
        main.setting.positionId = 'image_root_id'
        let imageSize = material.image_size;
        main.event.getResourceDirection(imageSize)
    }else if (main.setting.creative_type == 8) {
        main.setting.positionId = 'video_id'
        let videoSize = material.video_size;
        main.event.getResourceDirection(videoSize)
    }
    main.event.lottieBgEvent(main.lottie_bg);
    // main.event.lottieCardEvent(main.lottie_card);
    main.event.lottieWidgetEvent(main.lottie_widget);
}
main.event.makeNode = function (params) {
    if (params.type == 'LottieView') {
        if (params.nodeId == "lottie_bg_id") {
            main.lottie_bg = new kitex.Lottie(params);
        } else if (params.nodeId == "lottie_card_id") {
            main.lottie_card = new kitex.Lottie(params);
        } else if (params.nodeId ==  "widget_id")  {
            main.lottie_widget = new kitex.Lottie(params);
        }
        return;
    }
    if (params.type == 'Vpaid') {
        main.event.vpaidInit(params);
        return;
    }
    if (params.type == 'SkipView') {
        var control = new kitex.SkipViewControl(params);
        let ad = kitex.data.ads[0];
        let totalTime = ad.slot_ad_setting.splash_setting.show_duration;
        if (main.vpaid && main.vpaid.duration > 3) {
            totalTime = Math.min(main.vpaid.duration, totalTime);
        }
        let skipTime = totalTime;
        control.setTime(totalTime, skipTime);
        return;
    }
}
main.event.resourceSize = function(params) {
    console.log('[main].resourceSize:' + JSON.stringify(params));
    if (params.nodeId == "image_id") {
        // main.event.loadBg(params);
    }
}
main.event.getResourceDirection = function(params) {
    if (params.height < params.width) {
        main.setting.resourceDirection = 1;
    } 
    // main.event.lottieBgEvent(main.lottie_bg);
}
main.event.widgetId = function() {
    return '205115'
}
main.event.bgWidgetId = function() {
    return '502002'
}
main.event.cardWidgetId = function() {
    return '502002'
}
main.event.bgImagePath = function() {
    let bgWidgetId = main.event.bgWidgetId();
    let imagePath = kitex.path + "/" + bgWidgetId + "/BG-V/images/img_1.png";
    return imagePath;
}
main.event.lottieBgEvent = function (lottie) {
    let bgWidgetId = main.event.bgWidgetId();
    let containerPath = "_BG_POSTION_" + bgWidgetId + "_";
    lottie.addEventListener("animationLoaded", function (event) {
        lottie.play(0, 1, 0);
        if (main.setting.positionId) {
            lottie.addNode(containerPath, main.setting.positionId);
        }
        console.log("lottieBg.animation.completed");
    });
    lottie.addEventListener("completed", function (event) {
        console.log("lottieBg.animation.completed");
    });
    let resourceName = main.setting.resourceDirection == 0 ? "BG-V" : "BG-H";
    let imageProviderPath = kitex.path + "/" + bgWidgetId + "/" + resourceName + "/images/";
    let filepath = kitex.path + "/" + bgWidgetId + "/" + resourceName + "/"+ bgWidgetId + ".json";

    lottie.imageProvider(imageProviderPath);
    lottie.filepath(filepath);
    // 更改标题
    lottie.textProvider({"_AD_TITLE_":"广告"});
}
main.event.lottieCardEvent = function (lottie) {
    let cardWidgetId = main.event.cardWidgetId();
    let containerPath = "_BG_POSTION_" + cardWidgetId + "_";
    lottie.addEventListener("animationLoaded", function (event) {
        lottie.play(0, 1, 0);
        if (main.setting.positionId) {
            lottie.addNode(containerPath, main.setting.positionId);
        }
    });
    lottie.addEventListener("completed", function (event) {
        console.log("lottieCard.animation.completed");
    });
    let imageProviderPath = kitex.path + "/" + cardWidgetId + "/BG-V/images/";
    let filepath = kitex.path + "/" + cardWidgetId + "/BG-V/data.json";

    lottie.imageProvider(imageProviderPath);
    lottie.filepath(filepath);
}
main.event.lottieWidgetEvent = function (lottie) {
    lottie.addEventListener("animationLoaded", function (event) {
        lottie.play(0, 1, 0);
        main.event.interactiveEvent(lottie);
    });
    lottie.addEventListener("completed", function (event) {
        console.log("lottie.animation.completed");
    });
    let widgetId = main.event.widgetId();
    let imageProviderPath = kitex.path + "/" + widgetId  + "/images/";
    let filepath = kitex.path +  "/" + widgetId  + "/data.json";
    lottie.imageProvider(imageProviderPath);
    lottie.filepath(filepath);

}
/** 互动事件处理 */
main.event.interactiveEvent = function (lottie) {
    // 互动挂件
    let ad = kitex.data.ads[0];
    // console.log('[main].ad: ' + JSON.stringify(ad));
    let material = ad.materials[0];
    let adSetting = ad.ad_setting;
    let widgetId = main.event.widgetId();
    let interactiveType = main.utils.getInteractiveType(widgetId);
    let sensitivity = adSetting.sensitivity;
    if (interactiveType ==  InteractiveType.motion || interactiveType == InteractiveType.slide) { // 陀螺仪和滑动
        let motionType = main.utils.getMotionType(widgetId);
        if (motionType != MotionType.unknown) {
            main.motion = new kitex.Motion(motionType);
            main.event.motionEvent(main.motion);
        }
        // 互动组件点击
        if (material.click_type == 1) {
            // 挂件点击
            lottie.addClick("_CLICK_01_.png", function (params) {
                console.log('[main].widget.click: ' + JSON.stringify(params));
                kitex.ad.openByVid(params);
            });
            lottie.addClick("_CLICK_02_.png", function (params) {
                console.log('[main].widget.click: ' + JSON.stringify(params));
                kitex.ad.openByVid(params);
            });
        }
        // if (interactiveType == InteractiveType.slide) {
        //     let distance = main.utils.getSlideDistance(sensitivity);
        //     lottie.addSlide("滑动手机至banner动效", distance, function (params) {
        //         console.log('[main].widget.slide: ' + JSON.stringify(params));
        //         kitex.ad.openByVid(params);
        //     });
        // }
    }

    let title = material.title;
    let desc = material.desc;
    console.log('[main].title:' + title + "desc:" + desc);
    if (main.utils.isUseDefaultText(widgetId)) {
        if (isValidString(title)) {
            title =  main.utils.getDefaultTitle(widgetId);
        }
        if (isValidString(desc)) {
            desc =  main.utils.getDefaultDesc();
        }
    }
    console.log('[main].title:' + title + "desc:" + desc);
    lottie.textProvider({"_WIDGET_TITLE_":title});
    lottie.textProvider({"_WIDGET_DES_":desc});
}

function isValidString(val) {
    if (val == null || !(typeof val  === "string") || (typeof val === "string" || val.length == 0)) {
        return false
    }
    return true
}

main.event.motionEvent = function (motion) {
    motion.start();
    motion.addEventListener("start", function(params) {
        console.log('[main].motion.start: ' + JSON.stringify(params));
    });
    motion.addEventListener("end", function(params) {
        console.log('[main].motion.end: ' + JSON.stringify(params));
    });
    motion.addEventListener("progress", function(params) {
        console.log('[main].motion.progress: ' + JSON.stringify(params));
    });
}
main.event.vpaidInit = function (params) {
    let vpaid = new kitex.Vpaid(params);
    main.event.addVpaidEvent(vpaid);
    let video_url = kitex.data.ads[0].materials[0].video_url
    vpaid.assetURL(video_url);
    main.vpaid = vpaid;
}
main.event.vpaidReadyToPlay = function (vpaid) {
    vpaid.play();
}
main.event.vpaidPlayToEnd = function (vpaid) {
    kitex.postMessage({
        tid: vpaid.tid,
        type: vpaid.type,
        value: 'vpaidPlayToEnd',
        params: {
            nodeId: vpaid.nodeId
        }
    });
}
main.event.addVpaidEvent = function (vpaid) {
    vpaid.addEventListener('ready', function (params) {
        console.log('[main].prepareToPlay:' + JSON.stringify(params));
        main.event.vpaidReadyToPlay(vpaid);
        // main.event.loadBg(params);
    });
    vpaid.addEventListener('playStateChanged', function (params) {
        console.log('[main].playStateChanged:' + JSON.stringify(params));
    });
    vpaid.addEventListener('loadStateChanged', function (params) {
        console.log('[main].loadStateChanged:' + JSON.stringify(params));
    });
    vpaid.addEventListener('currentTime', function (params) {
        
    });
    vpaid.addEventListener('playEnd', function (params) {
        console.log('[main].playEnd:' + JSON.stringify(params));
        main.event.vpaidPlayToEnd(params);
    });
    vpaid.addEventListener('error', function (params) {
        console.log('[main].error:' + JSON.stringify(params));
    });
}
main.event.countDownListener = function() {
    main.track.countdownFinish();
    main.track.close();
    kitex.postMessage({
        tid: main.tid,
        type: 'ad',
        value: 'countdownFinish',
    });
}

main.event.skipClick = function (event) {
    main.track.clickSkip();
    main.track.close();
    kitex.ad.skip(event);
}

main.event.distance = function() {
    // console.log('[main].distance:' + JSON.stringify(kitex.data));
    let ad = kitex.data.ads[0];
    let adSetting = ad.ad_setting;
    let sensitivity = adSetting.sensitivity;
    let distance = main.utils.getSlideDistance(sensitivity);
    return distance;
}
main.event.click = function (params) {
    kitex.ad.openByVid(params);
    
}

