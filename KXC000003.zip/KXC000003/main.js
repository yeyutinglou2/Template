// 伴随条组件(标题+描述)
var KXC000003 = {
    tid: 'KXC000003',
}
// 监听事件 模版环境初始化完成
kitex.addEventListener(KXC000003.tid, 'ready', function () {
    console.log('---------- KXC000003.kitex.ready ----------');
})
KXC000003.color = {
    barColor: function() {
        console.log('---------- KXC000003.barColor ----------');
        return '#ffffff';
    },
    buttonColor: function() {
        console.log('---------- KXC000003.buttonColor ----------');
        return 'red';
    },
    buttonTextColor: function() {
        console.log('---------- KXC000003.buttonTextColor ----------');
        return 'white';
    }
}