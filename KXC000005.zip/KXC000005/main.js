// 反馈弹窗组件
var KXC000005 = {
    tid: 'KXC000005'
};
// 移除事件(反馈组件能够反复创建)
kitex.removeEventListener(KXC000005.tid, 'ready');
kitex.removeEventListener(KXC000005.tid, 'text_input');

// 监听事件 模版环境初始化完成
kitex.addEventListener(KXC000005.tid, 'ready', function () {
    console.log('---------- KXC000005.kitex.ready ----------');
    let vid = KXC000005.params.vid
    kitex.addDclog({
        category: "dislike",
        sub_category: "click",
    }, vid)
})
// 添加反馈输入框的完成事件
kitex.textInput.addEventListener(KXC000005.tid,'text_input', function (params) {
    let vid = KXC000005.params.vid
    kitex.addDclog({
        category: "dislike",
        sub_category: "advice",
        content: btoa(params.text)
    }, vid)
})
KXC000005.dislikeEvent = function(params) {
    let vid = KXC000005.params.vid
    kitex.addDclog(params, vid)
}
